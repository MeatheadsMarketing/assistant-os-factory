def parse_markdown(md_text):
    import re
    fields = {
        "title": re.search(r"^# (.+)", md_text, re.MULTILINE),
        "description": re.search(r"## Description\n(.+?)\n", md_text, re.DOTALL),
        "category": re.search(r"Category: (.+)", md_text),
        "inputs": re.findall(r"- Input: (.+)", md_text),
        "outputs": re.findall(r"- Output: (.+)", md_text),
    }
    return {k: (v.group(1).strip() if v else None) if not isinstance(v, list) else v for k, v in fields.items()}
