def smart_review(md_text):
    summary = "Assistant reviewed. Looks generally well-formed."
    suggestions = []
    if "TODO" in md_text or "fill in" in md_text.lower():
        suggestions.append("Contains placeholders like TODO – consider finalizing those.")
    if len(md_text.split()) < 100:
        suggestions.append("Very short markdown. Consider adding more detail.")
    return {"summary": summary, "suggestions": suggestions}

def suggest_enhancements(data):
    if not data.get("category"):
        data["category"] = "Data Cleaning"
    if data.get("description"):
        data["description"] += " This assistant was automatically enhanced for better clarity."
    return data
