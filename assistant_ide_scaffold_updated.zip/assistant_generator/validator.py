import os

def validate_assistant(folder):
    result = {
        "has_run_ui": False,
        "py_file_exists": False,
        "md_file_exists": False,
        "manifest_exists": False,
    }
    for file in os.listdir(folder):
        if file.endswith(".py"):
            result["py_file_exists"] = True
            with open(os.path.join(folder, file)) as f:
                result["has_run_ui"] = "def run_ui" in f.read()
        elif file.endswith(".md"):
            result["md_file_exists"] = True
        elif file == "manifest.json":
            result["manifest_exists"] = True
    result["status"] = "ok" if all(result.values()) else "incomplete"
    return result
