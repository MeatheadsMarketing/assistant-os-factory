import os
import json

def generate_assistant_files(data, md_text):
    name = data["title"].lower().replace(" ", "_")
    folder = f"assistants/{name}"
    os.makedirs(folder, exist_ok=True)

    with open(f"{folder}/{name}.md", "w") as f:
        f.write(md_text)

    with open(f"{folder}/{name}.py", "w") as f:
        f.write(f"""import streamlit as st\n\ndef run_ui():\n    st.title(\"{data['title']}\")\n    st.write(\"{data['description']}\")\n    # Add UI logic here\n\nif __name__ == '__main__':\n    run_ui()\n""")

    manifest = {
        "title": data["title"],
        "category": data.get("category", "Uncategorized"),
        "uses_gpt": "gpt" in md_text.lower(),
        "has_run_ui": True,
    }
    with open(f"{folder}/manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)

    return folder
