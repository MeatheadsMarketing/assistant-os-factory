import streamlit as st
import os
import zipfile
import json
from assistant_generator.parser import parse_markdown
from assistant_generator.generator import generate_assistant_files
from assistant_generator.validator import validate_assistant
from assistant_generator.intelligence_layer import smart_review, suggest_enhancements

def zip_folder(folder_path):
    zip_path = f"{folder_path}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, os.path.dirname(folder_path))
                zipf.write(file_path, arcname)
    return zip_path

def inject_into_launcher(manifest_entry, manifest_path="zip_manifest.json"):
    if os.path.exists(manifest_path):
        with open(manifest_path, "r") as f:
            manifest = json.load(f)
    else:
        manifest = []

    manifest.append(manifest_entry)

    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

def bundle_generated_folders(folders, bundle_path="assistant_bundle.zip"):
    with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for folder in folders:
            for root, _, files in os.walk(folder):
                for file in files:
                    fpath = os.path.join(root, file)
                    arcname = os.path.relpath(fpath, os.path.dirname(folder))
                    zipf.write(fpath, arcname)
    return bundle_path

def run_ui():
    st.set_page_config(page_title="Assistant Generator", layout="wide")
    st.title("📦 Markdown → Assistant Generator")

    if "generated_folders" not in st.session_state:
        st.session_state.generated_folders = []

    uploaded_md = st.file_uploader("Upload Assistant Markdown (.md)", type=["md"])

    if uploaded_md:
        md_text = uploaded_md.read().decode("utf-8")

        # Smart pre-generation review
        st.subheader("🔍 GPT Review & Suggestions")
        review = smart_review(md_text)
        st.markdown(review["summary"])
        if review["suggestions"]:
            st.warning("Suggestions to Improve:")
            for s in review["suggestions"]:
                st.markdown(f"- {s}")

        # Parsed content preview
        assistant_data = parse_markdown(md_text)
        st.subheader("📄 Parsed Fields")
        st.json(assistant_data)

        # Optional enhancement mode
        if st.checkbox("🔧 Apply GPT Enhancements Before Generating?"):
            assistant_data = suggest_enhancements(assistant_data)
            st.success("Enhancements applied.")
            st.json(assistant_data)

        inject_to_launcher = st.checkbox("➕ Add to Launcher Automatically")

        if st.button("🚀 Generate Assistant Folder"):
            folder_path = generate_assistant_files(assistant_data, md_text)
            validation_report = validate_assistant(folder_path)

            st.success(f"Assistant folder created at `{folder_path}`")
            st.subheader("✅ Validation Report")
            st.json(validation_report)

            with open(os.path.join(folder_path, "validation.json"), "w") as f:
                json.dump(validation_report, f, indent=2)

            st.session_state.generated_folders.append(folder_path)

            if inject_to_launcher:
                manifest_entry = {
                    "title": assistant_data["title"],
                    "category": assistant_data.get("category", "Uncategorized"),
                    "uses_gpt": "gpt" in md_text.lower(),
                    "has_run_ui": True,
                    "path": folder_path
                }
                inject_into_launcher(manifest_entry)
                st.success("Injected into launcher manifest.")

            py_file = [f for f in os.listdir(folder_path) if f.endswith(".py")][0]
            st.subheader("🧪 Assistant UI Preview (Code View)")
            st.code(open(os.path.join(folder_path, py_file)).read(), language="python")

            zip_path = zip_folder(folder_path)
            with open(zip_path, "rb") as f:
                st.download_button(
                    label="⬇️ Download Assistant ZIP",
                    data=f,
                    file_name=os.path.basename(zip_path),
                    mime="application/zip"
                )

    if st.session_state.generated_folders:
        st.markdown("---")
        st.subheader("📦 Bundle All Generated Assistants")
        if st.button("🗂 Create ZIP of All Assistants"):
            bundle_path = bundle_generated_folders(st.session_state.generated_folders)
            with open(bundle_path, "rb") as f:
                st.download_button(
                    label="⬇️ Download All Assistants Bundle",
                    data=f,
                    file_name=os.path.basename(bundle_path),
                    mime="application/zip"
                )

if __name__ == "__main__":
    run_ui()
