import streamlit as st
from assistant_generator.main_ui import run_ui as generator_ui
from assistant_dashboard.main_ui import run_ui as dashboard_ui
from unified_launcher.main_ui import run_ui as launcher_ui

st.set_page_config(page_title='Modular Assistant Suite', layout='wide')

TABS = {
    '🧠 Assistant Generator': generator_ui,
    '📊 Assistant Dashboard': dashboard_ui,
    '🚀 Unified Launcher': launcher_ui
}

tab = st.sidebar.radio('Select a View:', list(TABS.keys()))
TABS[tab]()
