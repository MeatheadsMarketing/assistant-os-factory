# v6.1_tag_filter_panel.py
"""Sidebar tag selector to filter UI tabs dynamically."""

import streamlit as st
st.set_page_config(page_title="v6.1_tag_filter_panel.py", layout="wide")
st.title("🧩 V6.1 Tag Filter Panel")

st.markdown("🔧 Sidebar tag selector to filter UI tabs dynamically.")
