# v6.7_gpt_suggest_next.py
"""Auto-suggest next assistant to run based on context."""

import streamlit as st
st.set_page_config(page_title="v6.7_gpt_suggest_next.py", layout="wide")
st.title("🧩 V6.7 Gpt Suggest Next")

st.markdown("🔧 Auto-suggest next assistant to run based on context.")
