# 📂 tools

Backend tools (v5.x–v10.x): CSV handlers, UI helpers, file exports, scoring panels.

---

This folder is part of the Modular Assistant OS Factory.