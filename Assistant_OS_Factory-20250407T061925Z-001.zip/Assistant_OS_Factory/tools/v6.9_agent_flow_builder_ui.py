# v6.9_agent_flow_builder_ui.py
"""Build agent chains visually with drag-and-drop inputs and schema."""

import streamlit as st
st.set_page_config(page_title="v6.9_agent_flow_builder_ui.py", layout="wide")
st.title("🧩 V6.9 Agent Flow Builder Ui")

st.markdown("🔧 Build agent chains visually with drag-and-drop inputs and schema.")
