# v5.1_colab_csv_ingestor.py
"""Colab helper to ingest, clean, and save CSVs from Drive or URL."""

import streamlit as st
st.set_page_config(page_title="v5.1_colab_csv_ingestor.py", layout="wide")
st.title("🧩 V5.1 Colab Csv Ingestor")

st.markdown("🔧 Colab helper to ingest, clean, and save CSVs from Drive or URL.")
