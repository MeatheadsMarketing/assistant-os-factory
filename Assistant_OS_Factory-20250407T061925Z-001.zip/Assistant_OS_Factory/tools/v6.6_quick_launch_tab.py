# v6.6_quick_launch_tab.py
"""Dropdown UI to instantly run any assistant with default config."""

import streamlit as st
st.set_page_config(page_title="v6.6_quick_launch_tab.py", layout="wide")
st.title("🧩 V6.6 Quick Launch Tab")

st.markdown("🔧 Dropdown UI to instantly run any assistant with default config.")
