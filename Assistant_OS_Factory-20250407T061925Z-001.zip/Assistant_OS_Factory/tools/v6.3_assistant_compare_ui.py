# v6.3_assistant_compare_ui.py
"""Select 2 assistants and compare schema, inputs, and scoring."""

import streamlit as st
st.set_page_config(page_title="v6.3_assistant_compare_ui.py", layout="wide")
st.title("🧩 V6.3 Assistant Compare Ui")

st.markdown("🔧 Select 2 assistants and compare schema, inputs, and scoring.")
