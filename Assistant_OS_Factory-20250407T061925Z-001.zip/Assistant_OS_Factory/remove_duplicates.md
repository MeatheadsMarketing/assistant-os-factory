# Remove Duplicate Rows

## Description
This assistant removes duplicate rows from a CSV dataset based on one or more selected columns. You can choose to keep the first or last occurrence.

Category: Data Cleaning

- Input: Raw CSV file with possible duplicates
- Output: Clean CSV with duplicates removed
