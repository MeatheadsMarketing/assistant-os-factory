# 📂 agent_core

Agent runtime logic (v4.x), including memory routing, reflection, execution.

---

This folder is part of the Modular Assistant OS Factory.