# 📂 flow_engine

DAG runners, flow managers, bundlers, and execution logic (v2.x–v3.x–v9.x).

---

This folder is part of the Modular Assistant OS Factory.