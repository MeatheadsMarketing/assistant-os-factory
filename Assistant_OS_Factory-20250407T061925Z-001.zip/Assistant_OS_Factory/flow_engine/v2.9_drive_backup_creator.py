import streamlit as st
import os
import zipfile

st.set_page_config(page_title="📦 Versioned Backup Tool", layout="wide")
st.title("📦 Create Backup Snapshot (v2.9)")

folder = "/content/drive/MyDrive/assistant_markdown"
version = st.text_input("Tag/Version Name", "v2.9_snapshot")

if st.button("🗂 Generate Backup"):
    zip_path = os.path.join(folder, f"{version}.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(folder):
            for file in files:
                full_path = os.path.join(root, file)
                arcname = os.path.relpath(full_path, folder)
                zipf.write(full_path, arcname)
    st.success(f"Backup created: {zip_path}")
