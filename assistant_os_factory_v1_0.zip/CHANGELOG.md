# Changelog

## v1.0 - Modular Assistant Factory
- GPT-enhanced markdown → assistant pipeline
- Streamlit-ready file output (.py, .md, manifest.json)
- Inline preview + validation
- Full ZIP packaging
- GitHub/Colab/Drive-compatible layout
