# ⚙️ Backend Assistant: Flow Runner with Retry

**ID**: `dag_08`  
**Filename**: `dag_08_flow_runner_with_retry.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Executes DAG with auto-retry on failure

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed Flow Runner with Retry",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Executes DAG with auto-retry on failure
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
