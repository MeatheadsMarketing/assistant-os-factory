# ⚙️ Backend Assistant: Loop Executor

**ID**: `dag_05`  
**Filename**: `dag_05_loop_executor.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Repeats node execution in for-loop or while-loop style

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed Loop Executor",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Repeats node execution in for-loop or while-loop style
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
