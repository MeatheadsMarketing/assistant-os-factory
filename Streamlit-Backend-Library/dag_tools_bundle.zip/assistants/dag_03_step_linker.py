"""
Backend Assistant: Step Linker
Description: Links outputs from one assistant to another
"""

def run(config):
    return {
        "status": "success",
        "assistant_id": "dag_03",
        "message": "Executed Step Linker with config",
        "input": config
    }
