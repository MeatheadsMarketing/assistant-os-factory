"""Score agents in a run based on output quality."""

# TODO: Implement logic for v4.4_agent_evaluator