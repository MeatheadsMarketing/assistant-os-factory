# ⚙️ Backend Assistant: Prompt Debugger

**ID**: `gpt_17`  
**Filename**: `gpt_17_prompt_debugger.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Interactive tool to test prompt behavior

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed Prompt Debugger",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Interactive tool to test prompt behavior
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
