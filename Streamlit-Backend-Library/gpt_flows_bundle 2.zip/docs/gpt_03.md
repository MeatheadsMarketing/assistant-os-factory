# ⚙️ Backend Assistant: Prompt Token Counter

**ID**: `gpt_03`  
**Filename**: `gpt_03_prompt_token_counter.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Counts token usage across prompts

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed Prompt Token Counter",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Counts token usage across prompts
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
