# ⚙️ Backend Assistant: Prompt Selector from Registry

**ID**: `gpt_08`  
**Filename**: `gpt_08_prompt_selector_from_registry.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Selects best prompt for a goal from prompt index

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed Prompt Selector from Registry",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Selects best prompt for a goal from prompt index
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
