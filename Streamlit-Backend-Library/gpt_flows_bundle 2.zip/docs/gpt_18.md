# ⚙️ Backend Assistant: JSON to Prompt Converter

**ID**: `gpt_18`  
**Filename**: `gpt_18_json_to_prompt_converter.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Converts structured fields to prompt format

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed JSON to Prompt Converter",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Converts structured fields to prompt format
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
