# ⚙️ Backend Assistant: GPT Prompt Generator from Goals

**ID**: `gpt_20`  
**Filename**: `gpt_20_gpt_prompt_generator_from_goals.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Builds prompts from plain English goals

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed GPT Prompt Generator from Goals",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Builds prompts from plain English goals
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
