# ⚙️ Backend Assistant: Role-based Prompt Wrapper

**ID**: `gpt_06`  
**Filename**: `gpt_06_role-based_prompt_wrapper.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Wraps prompt in persona/agent role context

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed Role-based Prompt Wrapper",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Wraps prompt in persona/agent role context
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
