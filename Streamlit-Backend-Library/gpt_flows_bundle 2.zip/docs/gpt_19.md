# ⚙️ Backend Assistant: LLM Tool Use Decider

**ID**: `gpt_19`  
**Filename**: `gpt_19_llm_tool_use_decider.py`  
**Execution Mode**: `run(config)`  
**Created**: 2025-04-06  
**Plugin Ready**: ✅  

---

### 🔍 Description  
Chooses assistant/tool based on intent

---

### 🔧 Function Signature
```python
def run(config: dict) -> dict:
    ...
```

---

### 🔢 Example `config` Input
```json
{
  "input_path": "data/sample.csv",
  "options": {
    "mode": "analyze",
    "params": { }
  }
}
```

---

### ✅ Example Output
```json
{
  "status": "success",
  "message": "Executed LLM Tool Use Decider",
  "results": { ... }
}
```

---

### 🧠 Use Cases
- Chooses assistant/tool based on intent
- Integration with modular DAG or GPT flow
- Server-side backend pipeline building

---
